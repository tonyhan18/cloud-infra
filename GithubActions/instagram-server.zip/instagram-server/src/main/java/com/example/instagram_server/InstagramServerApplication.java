package com.example.instagram_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstagramServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstagramServerApplication.class, args);
	}

}
